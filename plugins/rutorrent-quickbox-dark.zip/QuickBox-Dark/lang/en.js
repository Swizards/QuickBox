﻿/*
 * PLUGIN THEME
 *
 * English language file.
 *
 * Author: Jason Matthews - https://jmsolodesigns.com/
 */

 theUILang.themeStandard	= "QuickBox";
 theUILang.theme		= "Theme";

thePlugins.get("theme").langLoaded();